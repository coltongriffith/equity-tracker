const HEADERS = { "User-Agent": "Mozilla/5.0", Accept: "application/json" };

function normalizeTicker(value) {
  return String(value || "").trim().toUpperCase();
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "no-store, max-age=0");

  if (req.method === "OPTIONS") return res.status(204).end();

  const tickers = [...new Set(String(req.query?.tickers || "").split(",").map(normalizeTicker).filter(Boolean))];
  if (!tickers.length) return res.status(400).json({ error: "Missing tickers" });

  try {
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(tickers.join(","))}`;
    const response = await fetch(url, { headers: HEADERS });
    if (!response.ok) throw new Error(`Yahoo Finance returned ${response.status}`);
    const payload = await response.json();
    const results = payload?.quoteResponse?.result || [];
    const bySymbol = new Map(results.map(item => [normalizeTicker(item.symbol), item]));

    const quotes = tickers.map(ticker => {
      const item = bySymbol.get(ticker);
      return {
        requestedTicker: ticker,
        price: Number(item?.regularMarketPrice ?? item?.postMarketPrice ?? item?.preMarketPrice ?? NaN),
        currency: item?.currency || null,
        name: item?.shortName || item?.longName || null,
        exchange: item?.fullExchangeName || item?.exchange || null,
        marketState: item?.marketState || null,
        found: Boolean(item),
      };
    });

    return res.status(200).json({ quotes });
  } catch (error) {
    return res.status(500).json({ error: error?.message || "Unable to fetch prices" });
  }
}
