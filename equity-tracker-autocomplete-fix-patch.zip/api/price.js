const HEADERS = { "User-Agent": "Mozilla/5.0", Accept: "application/json" };

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "no-store, max-age=0");

  if (req.method === "OPTIONS") return res.status(204).end();

  const ticker = String(req.query?.ticker || "").trim().toUpperCase();
  if (!ticker) return res.status(400).json({ error: "Missing ticker param" });

  try {
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(ticker)}`;
    const response = await fetch(url, { headers: HEADERS });
    if (!response.ok) throw new Error(`Yahoo Finance returned ${response.status}`);
    const payload = await response.json();
    const item = payload?.quoteResponse?.result?.[0];
    return res.status(200).json({
      ticker,
      price: Number(item?.regularMarketPrice ?? item?.postMarketPrice ?? item?.preMarketPrice ?? NaN),
      currency: item?.currency || null,
      name: item?.shortName || item?.longName || null,
      exchange: item?.fullExchangeName || item?.exchange || null,
      marketState: item?.marketState || null,
      found: Boolean(item),
    });
  } catch (error) {
    return res.status(500).json({ error: error?.message || "Unable to fetch price" });
  }
}
