const HEADERS = { "User-Agent": "Mozilla/5.0", Accept: "application/json" };

function normalize(value) {
  return String(value || "").trim().toUpperCase();
}

function toStoredTicker(symbol, exchange, quoteType) {
  const sym = normalize(symbol);
  const ex = normalize(exchange);
  const qt = normalize(quoteType);
  if (!sym) return "";

  if (sym.endsWith('.TO') || ex.includes('TORONTO') || ex === 'TSX' || ex === 'TOR') return sym;
  if (sym.endsWith('.V') || ex.includes('VENTURE') || ex === 'TSXV' || ex === 'VAN') return sym;
  if (sym.endsWith('.CN') || ex.includes('CANADIAN SECURITIES') || ex === 'CSE' || ex === 'CNSX') return sym;
  if (["EQUITY", "ETF", "MUTUALFUND", "INDEX"].includes(qt)) return sym;
  return sym;
}

function normalizeResult(item) {
  const symbol = normalize(item?.symbol);
  const exchange = item?.exchDisp || item?.exchange || item?.exch || "";
  const type = item?.quoteType || item?.typeDisp || "";
  const storedTicker = toStoredTicker(symbol, exchange, type);
  return {
    symbol,
    storedTicker,
    name: item?.shortname || item?.longname || item?.name || "",
    exchange,
    type: item?.typeDisp || type || "",
    currency: item?.currency || null,
    price: Number(item?.regularMarketPrice ?? item?.price ?? NaN),
    score: Number(item?.score ?? 0),
  };
}

async function searchTickers(query) {
  const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&lang=en-US&region=US&quotesCount=12&newsCount=0`;
  const response = await fetch(url, { headers: HEADERS });

  if (!response.ok) {
    throw new Error(`Ticker search failed (${response.status})`);
  }

  const payload = await response.json();
  const quotes = Array.isArray(payload?.quotes) ? payload.quotes : [];

  const seen = new Set();
  const results = [];

  for (const item of quotes) {
    const normalized = normalizeResult(item);
    if (!normalized.symbol || !normalized.storedTicker) continue;
    const key = `${normalized.storedTicker}|${normalized.exchange}|${normalized.name}`;
    if (seen.has(key)) continue;
    seen.add(key);
    results.push(normalized);
  }

  return results
    .sort((a, b) => {
      const scoreDelta = (b.score || 0) - (a.score || 0);
      if (scoreDelta !== 0) return scoreDelta;
      return a.storedTicker.localeCompare(b.storedTicker);
    })
    .slice(0, 10);
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "no-store, max-age=0");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  const query = String(req.query?.q || "").trim();
  if (!query) {
    return res.status(400).json({ error: "Missing q param" });
  }

  try {
    const results = await searchTickers(query);
    return res.status(200).json({ results, requested: query });
  } catch (error) {
    return res.status(500).json({ error: error?.message || "Unable to search tickers" });
  }
}
