const FALLBACK_HEADERS = { "User-Agent": "Mozilla/5.0", Accept: "application/json" };

function normalizeTicker(value) {
  return String(value || "").trim().toUpperCase();
}

async function fetchBatch(tickers) {
  const symbols = tickers.join(",");
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(symbols)}`;
  const response = await fetch(url, {
    headers: FALLBACK_HEADERS,
  });

  if (!response.ok) {
    throw new Error(`Yahoo Finance returned ${response.status}`);
  }

  const payload = await response.json();
  const results = payload?.quoteResponse?.result || [];
  const resultMap = new Map(results.map(item => [normalizeTicker(item.symbol), item]));

  return tickers.map(requestedTicker => {
    const normalizedRequested = normalizeTicker(requestedTicker);
    const quote = resultMap.get(normalizedRequested);
    return {
      requestedTicker: normalizedRequested,
      price: Number(
        quote?.regularMarketPrice ??
        quote?.postMarketPrice ??
        quote?.preMarketPrice ??
        NaN
      ),
      currency: quote?.currency || null,
      name: quote?.shortName || quote?.longName || null,
      marketState: quote?.marketState || null,
      exchange: quote?.fullExchangeName || quote?.exchange || null,
      found: Boolean(quote),
    };
  });
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "no-store, max-age=0");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  const rawTickers = String(req.query?.tickers || "");
  const tickers = [...new Set(rawTickers.split(",").map(normalizeTicker).filter(Boolean))];

  if (!tickers.length) {
    return res.status(400).json({ error: "Missing tickers param" });
  }

  try {
    const quotes = await fetchBatch(tickers);
    return res.status(200).json({ quotes, requested: tickers.length });
  } catch (error) {
    return res.status(500).json({ error: error?.message || "Unable to fetch prices" });
  }
}
