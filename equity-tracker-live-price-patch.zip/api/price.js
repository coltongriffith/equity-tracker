export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "no-store, max-age=0");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  const ticker = String(req.query?.ticker || "").trim().toUpperCase();
  if (!ticker) {
    return res.status(400).json({ error: "Missing ticker param" });
  }

  try {
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(ticker)}`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: `Yahoo Finance error (${response.status})` });
    }

    const payload = await response.json();
    const quote = payload?.quoteResponse?.result?.[0];
    const price = Number(
      quote?.regularMarketPrice ??
      quote?.postMarketPrice ??
      quote?.preMarketPrice ??
      NaN
    );

    return res.status(200).json({
      ticker,
      price: Number.isFinite(price) ? price : null,
      currency: quote?.currency || null,
      name: quote?.shortName || quote?.longName || null,
      marketState: quote?.marketState || null,
      exchange: quote?.fullExchangeName || quote?.exchange || null,
    });
  } catch (error) {
    return res.status(500).json({ error: error?.message || "Unable to fetch price" });
  }
}
